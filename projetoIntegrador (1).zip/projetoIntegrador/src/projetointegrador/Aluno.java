package projetointegrador;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class Aluno extends JFrame {
    private JTextField jfMatricula;
    private JTable tabela;
    private DefaultTableModel modeloTabela;

    public Aluno() {
        setTitle("Aluno");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        criarBotoes();
        criarLabels();
        criarCamposTexto();
        criarTabela();
        setLocationRelativeTo(null);
    }

    private void criarLabels() {
        JLabel nomeAluno = new JLabel("Nome Aluno:");
        nomeAluno.setBounds(50, 20, 100, 30);
        add(nomeAluno);

        JLabel labelMatricula = new JLabel("Matrícula:");
        labelMatricula.setBounds(50, 55, 100, 30);
        add(labelMatricula);
    }

    private void criarCamposTexto() {
        JTextField jfNome = new JTextField();
        jfNome.setBounds(150, 20, 100, 25);
        add(jfNome);

        jfMatricula = new JTextField();
        jfMatricula.setBounds(150, 55, 100, 25);
        add(jfMatricula);
    }

    private void criarTabela() {
        tabela = new JTable();
        JScrollPane scrollPane = new JScrollPane(tabela);
        scrollPane.setBounds(50, 95, 400, 80);
        add(scrollPane);

        modeloTabela = new DefaultTableModel();
        modeloTabela.addColumn("Nome");
        modeloTabela.addColumn("Matrícula");
        modeloTabela.addColumn("Nota");
        modeloTabela.addColumn("Presença");
        tabela.setModel(modeloTabela);
    }

    private void criarBotoes() {
        
        //botato voltar ao inicio aluno
        JButton inicioBotao = new JButton("Voltar");
        inicioBotao.setBounds(100, 190, 150, 50);
        inicioBotao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                ProjetoIntegrador projetoIntegrador = new ProjetoIntegrador();
                setVisible(false);
            }
        });
        add(inicioBotao);

        
        //botao consultar do aluno
        JButton consultBotao = new JButton("Consultar");
        consultBotao.setBounds(290, 190, 150, 50);
        consultBotao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                String matricula = jfMatricula.getText();

                String url = "jdbc:mysql://localhost:3306/projeto"; //conectar ao banco projeto
                String username = "root";
                String password = "";

                try (Connection connection = DriverManager.getConnection(url, username, password)) {
                   
                    String sql = "SELECT * FROM projeto1 WHERE matricula = ?";
                    try (PreparedStatement statement = connection.prepareStatement(sql)) {
                        statement.setString(1, matricula);
                        ResultSet resultSet = statement.executeQuery();

                             //caso a matricula digitada pelo aluno não tenha no banco de dados
                        if (!resultSet.isBeforeFirst()) {
                           JOptionPane.showMessageDialog(
           
                        null, "Matrícula não encontrada!", "Erro", JOptionPane.ERROR_MESSAGE);
                        }  

                        
                        modeloTabela.setRowCount(0); //limpa a tabela 

                        while (resultSet.next()) {
                            String nome = resultSet.getString("Nome");
                            int matriculaResultado = resultSet.getInt("Matricula");
                            double nota = resultSet.getDouble("Nota");
                            String presenca = resultSet.getString("Presenca");

                            Object[] rowData = {nome, matriculaResultado, nota, presenca};
                            modeloTabela.addRow(rowData);
                        }

                        resultSet.close();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();   //apagar os dados inseridos
                }
            }
        });
        add(consultBotao);
    }

    public static void main(String[] args) {
        Aluno alunoFrame = new Aluno();
        alunoFrame.setVisible(true);
    }
}



