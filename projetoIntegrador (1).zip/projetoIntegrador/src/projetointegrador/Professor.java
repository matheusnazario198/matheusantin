package projetointegrador;


import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Professor extends JFrame {

    private JTextField campoNome;
    private JTextField campoMatricula;
    private JTextField campoNota;
    private JTextField campoPresenca;

    public Professor() {
        setTitle("Professor");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        criarBotoes();
        setLocationRelativeTo(null);
        criarLabels();
        criarCamposTexto();
    }

    private void criarLabels() {
        JLabel nomeAluno = new JLabel("Nome Aluno:");
        nomeAluno.setBounds(50, 20, 100, 30);
        add(nomeAluno);

        JLabel labelMatricula = new JLabel("Matrícula:");
        labelMatricula.setBounds(50, 55, 100, 30);
        add(labelMatricula);

        JLabel labelNota = new JLabel("Nota:");
        labelNota.setBounds(50, 95, 100, 30);
        add(labelNota);

        JLabel labelPresenca = new JLabel("Presença:");
        labelPresenca.setBounds(50, 130, 100, 30);
        add(labelPresenca);
        
        JLabel labelInforme = new JLabel("Prencher os campos!");
        labelInforme.setBounds(50, 165, 155, 30);
        add(labelInforme);
        
    }

    private void criarCamposTexto() { //campo textos
        campoNome = new JTextField();
        campoNome.setBounds(150, 20, 100, 25);
        add(campoNome);

        campoMatricula = new JTextField();
        campoMatricula.setBounds(150, 55, 100, 25);
        add(campoMatricula);

        campoNota = new JTextField();
        campoNota.setBounds(150, 95, 100, 25);
        add(campoNota);

        campoPresenca = new JTextField();
        campoPresenca.setBounds(150, 130, 100, 25);
        add(campoPresenca);
    }

    private void criarBotoes() {
        //botao voltar professor
        JButton inicioBotao = new JButton("Voltar");
        inicioBotao.setBounds(100, 250, 150, 50);
        inicioBotao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                ProjetoIntegrador projetoIntegrador = new ProjetoIntegrador();
                setVisible(false);
            }
        });
        add(inicioBotao);
        
        //botao lancar notas
        JButton lancarBotao = new JButton("Lançar (Gravar)");
        lancarBotao.setBounds(290, 250, 150, 50);
        
        lancarBotao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                double nota;
                double matricula;
                try { //try catch para caso o prfessor n tenha inserido corretamente
                    nota = Double.parseDouble(campoNota.getText());
                    matricula = Double.parseDouble(campoMatricula.getText());
                } catch (NumberFormatException e) {
                    JOptionPane.showMessageDialog(null, "Favor digitar os campos corretamente.", "Erro", JOptionPane.ERROR_MESSAGE);
                    return; 
                }

                String nomeAluno = campoNome.getText().trim();
                String matriculaStr = campoMatricula.getText().trim();
                String notaStr = campoNota.getText().trim();
                String presenca = campoPresenca.getText().trim();

                if (nomeAluno.isEmpty() || matriculaStr.isEmpty() || notaStr.isEmpty() || presenca.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Por favor, preencha todos os campos.", "Erro", JOptionPane.ERROR_MESSAGE);
                    return; 
                }

                String url = "jdbc:mysql://localhost:3306/projeto";
                String username = "root";
                String password = "";

                try (Connection connection = DriverManager.getConnection(url, username, password)) {
                    String sql = "INSERT INTO projeto1 (nome, matricula, nota, presenca) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement statement = connection.prepareStatement(sql)) {
                        statement.setString(1, nomeAluno);
                        statement.setDouble(2, matricula);
                        statement.setDouble(3, nota);
                        statement.setString(4, presenca);
                        statement.executeUpdate();
                    }

                    campoNome.setText("");
                    campoMatricula.setText("");
                    campoNota.setText("");
                    campoPresenca.setText("");

                } catch (SQLException e) {
                    e.printStackTrace(); // Tratar a exceção de banco de dados
                }
            }
        });

        add(lancarBotao);
    }
    public static void main(String[] args) {
        Professor professorFrame = new Professor();
        professorFrame.setVisible(true);
    }
}
