package projetointegrador;

import javax.swing.JButton;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProjetoIntegrador {

    private JFrame frame;
    private JButton professorBotao;
    private JButton alunoBotao;

    public static void main(String[] args) {
        ProjetoIntegrador projetoIntegrador = new ProjetoIntegrador();
        projetoIntegrador.createAndShowGUI();
    }

    public void createAndShowGUI() { //frame de inicio quando roda o progama
        frame = new JFrame("Sistema Universitário IFSC - Projeto 2023");
        frame.setSize(700, 550);
        frame.setLayout(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        criarBotoes();
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
    }

    public void criarBotoes() { // metodo para criar os dois botoes da tela incial 
        
        professorBotao = new JButton("Professor(A)"); //botao Professor
        professorBotao.setBounds(250, 120, 150, 50);
        professorBotao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                Professor professorFrame = new Professor();
                professorFrame.setVisible(true);
            }
        });

        alunoBotao = new JButton("Aluno(A)"); //botao aluno
        alunoBotao.setBounds(250, 200, 150, 50);
        alunoBotao.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                Aluno alunoFrame = new Aluno();
                alunoFrame.setVisible(true);
            }
        });

        frame.add(professorBotao);
        frame.add(alunoBotao);
    }

    public JFrame getFrame() {
        return frame;
    }

    public JButton getProfessorBotao() {
        return professorBotao;
    }

    public JButton getAlunoBotao() {
        return alunoBotao;
    }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
