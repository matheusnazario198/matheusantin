import java.awt.Component;
import javax.swing.JButton;
import javax.swing.JFrame;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import projetointegrador.ProjetoIntegrador;

public class ProjetoIntegradorTest {
    
    private ProjetoIntegrador p;
    
    public ProjetoIntegradorTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
      
        
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
         p = new ProjetoIntegrador();
    }
    
    @After
    public void tearDown() {
        
    }
    
    /**
     * Testa a criação dos botões no JFrame.
     */
    @Test
    public void testCriarBotoes() {
      p.criarBotoes(); // Chama o método a ser testado

        JFrame frame = p.getFrame(); // Obtém a instância do JFrame criada em ProjetoIntegrador
        Component[] components = frame.getContentPane().getComponents(); // Obtém os componentes do JFrame

        // Verifica os resultados esperados usando asserções
        assertEquals(2, components.length); // Verifica se existem 2 botões criados no JFrame

        // Verifica o texto dos botões
        if (components[0] instanceof JButton) {
            JButton professorBotao = (JButton) components[0];
            assertEquals("Professor(A)", professorBotao.getText()); // Verifica o texto do botão Professor
        }
        
        if (components[1] instanceof JButton) {
            JButton alunoBotao = (JButton) components[1];
            assertEquals("Aluno(A)", alunoBotao.getText()); // Verifica o texto do botão Aluno
        }
    }      
}
